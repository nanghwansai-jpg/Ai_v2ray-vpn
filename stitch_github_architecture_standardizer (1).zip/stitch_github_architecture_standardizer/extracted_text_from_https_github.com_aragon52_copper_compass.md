Skip to content

## Navigation Menu

[](/)

[Sign in](/login?return_to=https%3A%2F%2Fgithub.com%2FAragon52%2Fcopper-compass)

Appearance settings

  * Platform

    * AI CODE CREATION
      * [GitHub CopilotWrite better code with AI](https://github.com/features/copilot)
      * [GitHub Copilot appDirect agents from issue to merge](https://github.com/features/ai/github-app)
      * [MCP RegistryIntegrate external tools](https://github.com/mcp)

    * DEVELOPER WORKFLOWS
      * [ActionsAutomate any workflow](https://github.com/features/actions)
      * [CodespacesInstant dev environments](https://github.com/features/codespaces)
      * [IssuesPlan and track work](https://github.com/features/issues)
      * [Code ReviewManage code changes](https://github.com/features/code-review)
      * [Code QualityEnforce quality at merge](https://github.com/features/code-quality)

    * APPLICATION SECURITY
      * [GitHub Advanced SecurityFind and fix vulnerabilities](https://github.com/security/advanced-security)
      * [Code securitySecure your code as you build](https://github.com/security/advanced-security/code-security)
      * [Secret protectionStop leaks before they start](https://github.com/security/advanced-security/secret-protection)

    * EXPLORE
      * [Why GitHub](https://github.com/why-github)
      * [Documentation](https://docs.github.com)
      * [Blog](https://github.blog)
      * [Changelog](https://github.blog/changelog)
      * [Marketplace](https://github.com/marketplace)

[View all features](https://github.com/features)

  * Solutions

    * BY COMPANY SIZE
      * [Enterprises](https://github.com/enterprise)
      * [Small and medium teams](https://github.com/team)
      * [Startups](https://github.com/enterprise/startups)
      * [Nonprofits](https://github.com/solutions/industry/nonprofits)

    * BY USE CASE
      * [App Modernization](https://github.com/solutions/use-case/app-modernization)
      * [DevSecOps](https://github.com/solutions/use-case/devsecops)
      * [DevOps](https://github.com/solutions/use-case/devops)
      * [CI/CD](https://github.com/solutions/use-case/ci-cd)
      * [View all use cases](https://github.com/solutions/use-case)

    * BY INDUSTRY
      * [Healthcare](https://github.com/solutions/industry/healthcare)
      * [Financial services](https://github.com/solutions/industry/financial-services)
      * [Manufacturing](https://github.com/solutions/industry/manufacturing)
      * [Government](https://github.com/solutions/industry/government)
      * [View all industries](https://github.com/solutions/industry)

[View all solutions](https://github.com/solutions)

  * Resources

    * EXPLORE BY TOPIC
      * [AI](https://github.com/resources/articles?topic=ai)
      * [Software Development](https://github.com/resources/articles?topic=software-development)
      * [DevOps](https://github.com/resources/articles?topic=devops)
      * [Security](https://github.com/resources/articles?topic=security)
      * [View all topics](https://github.com/resources/articles)

    * EXPLORE BY TYPE
      * [Customer stories](https://github.com/customer-stories)
      * [Events & webinars](https://github.com/resources/events)
      * [Ebooks & reports](https://github.com/resources/whitepapers)
      * [Business insights](https://github.com/solutions/executive-insights)
      * [GitHub Skills](https://skills.github.com)

    * SUPPORT & SERVICES
      * [Documentation](https://docs.github.com)
      * [Customer support](https://support.github.com)
      * [Community forum](https://github.com/orgs/community/discussions)
      * [Trust center](https://github.com/trust-center)
      * [Partners](https://github.com/partners)

[View all resources](https://github.com/resources)

  * Open Source

    * COMMUNITY
      * [GitHub SponsorsFund open source developers](https://github.com/open-source/sponsors)

    * PROGRAMS
      * [Security Lab](https://securitylab.github.com)
      * [Maintainer Community](https://maintainers.github.com)
      * [GitHub Stars](https://stars.github.com)
      * [Archive Program](https://archiveprogram.github.com)

    * REPOSITORIES
      * [Topics](https://github.com/topics)
      * [Trending](https://github.com/trending)
      * [Collections](https://github.com/collections)

  * Enterprise

    * ENTERPRISE SOLUTIONS
      * [Enterprise platformAI-powered developer platform](https://github.com/enterprise)

    * AVAILABLE ADD-ONS
      * [GitHub Advanced SecurityEnterprise-grade security features](https://github.com/security/advanced-security)
      * [Copilot for BusinessEnterprise-grade AI features](https://github.com/features/copilot/copilot-business)
      * [Premium SupportEnterprise-grade 24/7 support](https://github.com/enterprise/premium-support)

  * [Pricing](https://github.com/pricing)



Search`/`

[Sign in](/login?return_to=https%3A%2F%2Fgithub.com%2FAragon52%2Fcopper-compass)

[Sign up](/signup?ref_cta=Sign+up&ref_loc=header+logged+out&ref_page=%2F%3Cuser-name%3E%2F%3Crepo-name%3E&source=header-repo&source_repo=Aragon52%2Fcopper-compass)

Appearance settings

You signed in with another tab or window. [Reload]() to refresh your session. You signed out in another tab or window. [Reload]() to refresh your session. You switched accounts on another tab or window. [Reload]() to refresh your session. Dismiss alert

{{ message }}

  1. [Aragon52](/Aragon52)
  2. [copper-compass](/Aragon52/copper-compass)



## Repository navigation

  *   * [Code](/Aragon52/copper-compass)
  * [Issues](/Aragon52/copper-compass/issues)
  * [Pull requests](/Aragon52/copper-compass/pulls)
  * [Actions](/Aragon52/copper-compass/actions)
  * [Projects](/Aragon52/copper-compass/projects)
  * [Security and quality](/Aragon52/copper-compass/security)
  * [Insights](/Aragon52/copper-compass/pulse)



More items

[](/Aragon52/copper-compass)

**[copper-compass](/Aragon52/copper-compass)**

Public

  * [Notifications](/login?return_to=%2FAragon52%2Fcopper-compass)You must be signed in to change notification settings
  * [Fork0 (0)](/login?return_to=%2FAragon52%2Fcopper-compass)
  * [Star0 (0)](/login?return_to=%2FAragon52%2Fcopper-compass)You must be signed in to star a repository



## About

No description, website, or topics provided.

### Resources

Readme

[Activity](/Aragon52/copper-compass/activity)

### Stars

**0** stars

### Watchers

**0** watching

### Forks

[**0** forks](/Aragon52/copper-compass/forks)

[Report repository](/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2FAragon52%2Fcopper-compass&report=Aragon52+%28user%29)

main

[Branches](/Aragon52/copper-compass/branches)[Tags](/Aragon52/copper-compass/tags)

[](/Aragon52/copper-compass/branches)[](/Aragon52/copper-compass/tags)

Go to file

Code

Open more actions menu

## Latest commit

 

## History

[103 Commits](/Aragon52/copper-compass/commits/main/)

[](/Aragon52/copper-compass/commits/main/)103 Commits

## Folders and files

Name| Name| Last commit message| Last commit date  
---|---|---|---  
[.github/workflows](/Aragon52/copper-compass/tree/main/.github/workflows "This path skips through empty directories")| [.github/workflows](/Aragon52/copper-compass/tree/main/.github/workflows "This path skips through empty directories")|  |    
[.lovable](/Aragon52/copper-compass/tree/main/.lovable ".lovable")| [.lovable](/Aragon52/copper-compass/tree/main/.lovable ".lovable")|  |    
[android-web](/Aragon52/copper-compass/tree/main/android-web "android-web")| [android-web](/Aragon52/copper-compass/tree/main/android-web "android-web")|  |    
[android](/Aragon52/copper-compass/tree/main/android "android")| [android](/Aragon52/copper-compass/tree/main/android "android")|  |    
[assets](/Aragon52/copper-compass/tree/main/assets "assets")| [assets](/Aragon52/copper-compass/tree/main/assets "assets")|  |    
[docs](/Aragon52/copper-compass/tree/main/docs "docs")| [docs](/Aragon52/copper-compass/tree/main/docs "docs")|  |    
[drizzle](/Aragon52/copper-compass/tree/main/drizzle "drizzle")| [drizzle](/Aragon52/copper-compass/tree/main/drizzle "drizzle")|  |    
[public](/Aragon52/copper-compass/tree/main/public "public")| [public](/Aragon52/copper-compass/tree/main/public "public")|  |    
[scripts](/Aragon52/copper-compass/tree/main/scripts "scripts")| [scripts](/Aragon52/copper-compass/tree/main/scripts "scripts")|  |    
[src](/Aragon52/copper-compass/tree/main/src "src")| [src](/Aragon52/copper-compass/tree/main/src "src")|  |    
[supabase](/Aragon52/copper-compass/tree/main/supabase "supabase")| [supabase](/Aragon52/copper-compass/tree/main/supabase "supabase")|  |    
[.env](/Aragon52/copper-compass/blob/main/.env ".env")| [.env](/Aragon52/copper-compass/blob/main/.env ".env")|  |    
[.gitignore](/Aragon52/copper-compass/blob/main/.gitignore ".gitignore")| [.gitignore](/Aragon52/copper-compass/blob/main/.gitignore ".gitignore")|  |    
[.prettierignore](/Aragon52/copper-compass/blob/main/.prettierignore ".prettierignore")| [.prettierignore](/Aragon52/copper-compass/blob/main/.prettierignore ".prettierignore")|  |    
[.prettierrc](/Aragon52/copper-compass/blob/main/.prettierrc ".prettierrc")| [.prettierrc](/Aragon52/copper-compass/blob/main/.prettierrc ".prettierrc")|  |    
[AGENTS.md](/Aragon52/copper-compass/blob/main/AGENTS.md "AGENTS.md")| [AGENTS.md](/Aragon52/copper-compass/blob/main/AGENTS.md "AGENTS.md")|  |    
[README.md](/Aragon52/copper-compass/blob/main/README.md "README.md")| [README.md](/Aragon52/copper-compass/blob/main/README.md "README.md")|  |    
[bun.lock](/Aragon52/copper-compass/blob/main/bun.lock "bun.lock")| [bun.lock](/Aragon52/copper-compass/blob/main/bun.lock "bun.lock")|  |    
[bunfig.toml](/Aragon52/copper-compass/blob/main/bunfig.toml "bunfig.toml")| [bunfig.toml](/Aragon52/copper-compass/blob/main/bunfig.toml "bunfig.toml")|  |    
[capacitor.config.ts](/Aragon52/copper-compass/blob/main/capacitor.config.ts "capacitor.config.ts")| [capacitor.config.ts](/Aragon52/copper-compass/blob/main/capacitor.config.ts "capacitor.config.ts")|  |    
[components.json](/Aragon52/copper-compass/blob/main/components.json "components.json")| [components.json](/Aragon52/copper-compass/blob/main/components.json "components.json")|  |    
[eslint.config.js](/Aragon52/copper-compass/blob/main/eslint.config.js "eslint.config.js")| [eslint.config.js](/Aragon52/copper-compass/blob/main/eslint.config.js "eslint.config.js")|  |    
[package-lock.json](/Aragon52/copper-compass/blob/main/package-lock.json "package-lock.json")| [package-lock.json](/Aragon52/copper-compass/blob/main/package-lock.json "package-lock.json")|  |    
[package.json](/Aragon52/copper-compass/blob/main/package.json "package.json")| [package.json](/Aragon52/copper-compass/blob/main/package.json "package.json")|  |    
[roadmap.md](/Aragon52/copper-compass/blob/main/roadmap.md "roadmap.md")| [roadmap.md](/Aragon52/copper-compass/blob/main/roadmap.md "roadmap.md")|  |    
[tsconfig.json](/Aragon52/copper-compass/blob/main/tsconfig.json "tsconfig.json")| [tsconfig.json](/Aragon52/copper-compass/blob/main/tsconfig.json "tsconfig.json")|  |    
[vite.config.ts](/Aragon52/copper-compass/blob/main/vite.config.ts "vite.config.ts")| [vite.config.ts](/Aragon52/copper-compass/blob/main/vite.config.ts "vite.config.ts")|  |    
[vitest.config.ts](/Aragon52/copper-compass/blob/main/vitest.config.ts "vitest.config.ts")| [vitest.config.ts](/Aragon52/copper-compass/blob/main/vitest.config.ts "vitest.config.ts")|  |    
View all files  
  
## Repository files navigation

  *   * README



More items

# Copper Compass

Build the "Ai V2Ray Client" web app reproducing the exact design system and features from the native Jetpack Compose project:

  1. Design Language & Theme:


  * Brushed-steel and burnished-copper precision instrument aesthetic.
  * Color palette: 
    * Steel: Base (#2C3035), Mid tray surface (#3F454C), Highlight bevel (#5A626C), Shadow (#0E1013), DeepInk (#06070A)
    * Copper: Front needle & titles (#C87547), Highlight (#E8C99A), Bevel (#7A4A1F), Glow (#E8B274)
    * Iron / Accents: EngraveLight (#9AA1A8), OffLineBorder (#B89A5C), StatusLed (#E53935), OnlineLed (#4CAF50)
  * Metallic recessed trays (SteelTray) with vertical chamfers and inner shadows, engraved keycap buttons, and glowing copper indicators.


  2. Navigation & Layout (Mobile-first PWA / Capacitor layout with desktop centering):


  * Top Header: Status LED indicator, "Ai V2Ray Client" title in burnished copper, status badge ("OFFLINE" in red or "CONNECTED" in glowing copper/green).
  * Recessed pill navigation bar with 3 tabs: 
    * CONNECTION (Bolt icon)
    * SETTINGS (Settings icon)
    * INFO (Info icon)


  3. Connection Tab:


  * AI Assist Panel: 
    * Header: Glowing copper badge with "AI · Ask Gemini"
    * Purpose input field: "What do you want to use the VPN for? Type platform or paste raw key (vmess://, vless://, trojan://, ss://)"
    * Gemini API key input field
    * Quick action chips: "PUBG Mobile", "Facebook & IG", "YouTube 4K", "Low Latency Gaming", "Anti-Censorship"
    * AI recommendation trigger that analyzes the user's intent and suggests the best server configuration / protocol.
  * Active Server Summary Card: Shows currently selected node name, protocol badge, ping, and server location flag.
  * Server Management Drawer / Modal: 
    * List of servers with latency tags and selection check.
    * "Add Server" button supporting: manual config, paste URI link (`vmess://`, `vless://`, `trojan://`, `ss://`), import subscription URL, or QR code scanner (webcam or file upload).
  * Instrument Gauge Dials & Power Controls: 
    * Left Dial: 270-degree metallic analog gauge with copper needle for "LATENCY PING" (ms).
    * Center Power Button: Large circular brushed-steel button with embossed copper bolt icon, tactile click effect, and glowing radial aura when active. Toggling simulates connection lifecycle (connecting handshake -> connected with live telemetry).
    * Right Dial: 270-degree analog gauge with copper needle for "SPEED RATE" (Mbps / KBps) with animated telemetry when connected.


  4. Settings Tab:


  * Device & Network: 
    * Kill Switch toggle
    * DNS selector (Cloudflare 1.1.1.1, Google 8.8.8.8, AdGuard, Quad9, Custom)
    * Protocol toggles (VLESS, VMESS, Trojan, Shadowsocks)
    * Routing rules: Global, Bypass LAN, Bypass Mainland/Domestic, Rule-based
    * SOCKS5 / HTTP local proxy port display (10808 / 10809)
  * Appearance & Theme display: Brushed Steel & Burnished Copper design tokens.
  * Export Xray / V2Ray JSON configuration button and clipboard copy.


  5. Information Tab:


  * Device & connection diagnostic information: App Version 2.4.1, protocols, simulated client IP & server exit IP, subscription status.
  * Zero-Log & Data Safety privacy card: No telemetry, no ad SDKs, local-only configuration parsing.
  * Guide on exporting to native Android using Capacitor (`npx cap add android`).


  6. Local Config Parser Engine:


  * Include the functional local parser that parses `vmess://` (base64 JSON), `vless://`, `trojan://`, and `ss://` URIs directly in TypeScript into valid Xray JSON configurations. Include preset test nodes so the UI is immediately interactive.



This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/0b12b832-408c-41d2-b1c3-a5260c1d457b).

  * **Ship faster** : describe what you want to build and Lovable handles the code.
  * **Stay in sync** : every change made in Lovable is committed straight to this repository.
  * **Full ownership** : this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.



## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).
```
 
    git clone <this-repository-url>
    cd <repository-name>
    npm i
    npm run dev

```

## Android

Android packaging and tagged GitHub releases are documented in [docs/android-release.md](/Aragon52/copper-compass/blob/main/docs/android-release.md). The Android shell preserves the deployed web UI; it does not provide a native VPN service.

## About

No description, website, or topics provided.

### Resources

Readme

[Activity](/Aragon52/copper-compass/activity)

### Stars

**0** stars

### Watchers

**0** watching

### Forks

[**0** forks](/Aragon52/copper-compass/forks)

[Report repository](/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2FAragon52%2Fcopper-compass&report=Aragon52+%28user%29)

## Releases

## Packages

## Contributors

## Languages

## Footer

[ ](https://github.com) (C) 2026 GitHub, Inc. 

### Footer navigation

  * [Terms](https://docs.github.com/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/site-policy/privacy-policies/github-privacy-statement)
  * [Security](https://github.com/security)
  * [Status](https://www.githubstatus.com/)
  * [Community](https://github.community/)
  * [Docs](https://docs.github.com/)
  * [Contact](https://support.github.com?tags=dotcom-footer)
  * Manage cookies 
  * Do not share my personal information 



You can’t perform that action at this time.