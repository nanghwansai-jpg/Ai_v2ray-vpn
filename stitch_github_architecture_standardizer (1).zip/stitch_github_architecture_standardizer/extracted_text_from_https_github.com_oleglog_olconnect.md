Skip to content

## Navigation Menu

[](/)

[Sign in](/login?return_to=https%3A%2F%2Fgithub.com%2FOleglog%2FOlConnect)

Appearance settings

  * Platform

    * AI CODE CREATION
      * [GitHub CopilotWrite better code with AI](https://github.com/features/copilot)
      * [GitHub Copilot appDirect agents from issue to merge](https://github.com/features/ai/github-app)
      * [MCP RegistryIntegrate external tools](https://github.com/mcp)

    * DEVELOPER WORKFLOWS
      * [ActionsAutomate any workflow](https://github.com/features/actions)
      * [CodespacesInstant dev environments](https://github.com/features/codespaces)
      * [IssuesPlan and track work](https://github.com/features/issues)
      * [Code ReviewManage code changes](https://github.com/features/code-review)
      * [Code QualityEnforce quality at merge](https://github.com/features/code-quality)

    * APPLICATION SECURITY
      * [GitHub Advanced SecurityFind and fix vulnerabilities](https://github.com/security/advanced-security)
      * [Code securitySecure your code as you build](https://github.com/security/advanced-security/code-security)
      * [Secret protectionStop leaks before they start](https://github.com/security/advanced-security/secret-protection)

    * EXPLORE
      * [Why GitHub](https://github.com/why-github)
      * [Documentation](https://docs.github.com)
      * [Blog](https://github.blog)
      * [Changelog](https://github.blog/changelog)
      * [Marketplace](https://github.com/marketplace)

[View all features](https://github.com/features)

  * Solutions

    * BY COMPANY SIZE
      * [Enterprises](https://github.com/enterprise)
      * [Small and medium teams](https://github.com/team)
      * [Startups](https://github.com/enterprise/startups)
      * [Nonprofits](https://github.com/solutions/industry/nonprofits)

    * BY USE CASE
      * [App Modernization](https://github.com/solutions/use-case/app-modernization)
      * [DevSecOps](https://github.com/solutions/use-case/devsecops)
      * [DevOps](https://github.com/solutions/use-case/devops)
      * [CI/CD](https://github.com/solutions/use-case/ci-cd)
      * [View all use cases](https://github.com/solutions/use-case)

    * BY INDUSTRY
      * [Healthcare](https://github.com/solutions/industry/healthcare)
      * [Financial services](https://github.com/solutions/industry/financial-services)
      * [Manufacturing](https://github.com/solutions/industry/manufacturing)
      * [Government](https://github.com/solutions/industry/government)
      * [View all industries](https://github.com/solutions/industry)

[View all solutions](https://github.com/solutions)

  * Resources

    * EXPLORE BY TOPIC
      * [AI](https://github.com/resources/articles?topic=ai)
      * [Software Development](https://github.com/resources/articles?topic=software-development)
      * [DevOps](https://github.com/resources/articles?topic=devops)
      * [Security](https://github.com/resources/articles?topic=security)
      * [View all topics](https://github.com/resources/articles)

    * EXPLORE BY TYPE
      * [Customer stories](https://github.com/customer-stories)
      * [Events & webinars](https://github.com/resources/events)
      * [Ebooks & reports](https://github.com/resources/whitepapers)
      * [Business insights](https://github.com/solutions/executive-insights)
      * [GitHub Skills](https://skills.github.com)

    * SUPPORT & SERVICES
      * [Documentation](https://docs.github.com)
      * [Customer support](https://support.github.com)
      * [Community forum](https://github.com/orgs/community/discussions)
      * [Trust center](https://github.com/trust-center)
      * [Partners](https://github.com/partners)

[View all resources](https://github.com/resources)

  * Open Source

    * COMMUNITY
      * [GitHub SponsorsFund open source developers](https://github.com/open-source/sponsors)

    * PROGRAMS
      * [Security Lab](https://securitylab.github.com)
      * [Maintainer Community](https://maintainers.github.com)
      * [GitHub Stars](https://stars.github.com)
      * [Archive Program](https://archiveprogram.github.com)

    * REPOSITORIES
      * [Topics](https://github.com/topics)
      * [Trending](https://github.com/trending)
      * [Collections](https://github.com/collections)

  * Enterprise

    * ENTERPRISE SOLUTIONS
      * [Enterprise platformAI-powered developer platform](https://github.com/enterprise)

    * AVAILABLE ADD-ONS
      * [GitHub Advanced SecurityEnterprise-grade security features](https://github.com/security/advanced-security)
      * [Copilot for BusinessEnterprise-grade AI features](https://github.com/features/copilot/copilot-business)
      * [Premium SupportEnterprise-grade 24/7 support](https://github.com/enterprise/premium-support)

  * [Pricing](https://github.com/pricing)



Search`/`

[Sign in](/login?return_to=https%3A%2F%2Fgithub.com%2FOleglog%2FOlConnect)

[Sign up](/signup?ref_cta=Sign+up&ref_loc=header+logged+out&ref_page=%2F%3Cuser-name%3E%2F%3Crepo-name%3E&source=header-repo&source_repo=Oleglog%2FOlConnect)

Appearance settings

You signed in with another tab or window. [Reload]() to refresh your session. You signed out in another tab or window. [Reload]() to refresh your session. You switched accounts on another tab or window. [Reload]() to refresh your session. Dismiss alert

{{ message }}

  1. [Oleglog](/Oleglog)
  2. [OlConnect](/Oleglog/OlConnect)



## Repository navigation

  *   * [Code](/Oleglog/OlConnect)
  * [Issues4 (4)](/Oleglog/OlConnect/issues)
  * [Pull requests](/Oleglog/OlConnect/pulls)
  * [Actions](/Oleglog/OlConnect/actions)
  * [Projects](/Oleglog/OlConnect/projects)
  * [Security and quality](/Oleglog/OlConnect/security)
  * [Insights](/Oleglog/OlConnect/pulse)



More items

[](/Oleglog/OlConnect)

**[OlConnect](/Oleglog/OlConnect)**

Public

  * [Notifications](/login?return_to=%2FOleglog%2FOlConnect)You must be signed in to change notification settings
  * [Fork3 (3)](/login?return_to=%2FOleglog%2FOlConnect)
  * [Star21 (21)](/login?return_to=%2FOleglog%2FOlConnect)You must be signed in to star a repository



## About

No description, website, or topics provided.

### Resources

Readme

License

[Activity](/Oleglog/OlConnect/activity)

### Stars

**21** stars

### Watchers

**2** watching

### Forks

[**3** forks](/Oleglog/OlConnect/forks)

[Report repository](/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2FOleglog%2FOlConnect&report=Oleglog+%28user%29)

main

[Branches](/Oleglog/OlConnect/branches)[Tags](/Oleglog/OlConnect/tags)

[](/Oleglog/OlConnect/branches)[](/Oleglog/OlConnect/tags)

Go to file

Code

Open more actions menu

## Latest commit

 

## History

[187 Commits](/Oleglog/OlConnect/commits/main/)

[](/Oleglog/OlConnect/commits/main/)187 Commits

## Folders and files

Name| Name| Last commit message| Last commit date  
---|---|---|---  
[.github/workflows](/Oleglog/OlConnect/tree/main/.github/workflows "This path skips through empty directories")| [.github/workflows](/Oleglog/OlConnect/tree/main/.github/workflows "This path skips through empty directories")|  |    
[app](/Oleglog/OlConnect/tree/main/app "app")| [app](/Oleglog/OlConnect/tree/main/app "app")|  |    
[gradle](/Oleglog/OlConnect/tree/main/gradle "gradle")| [gradle](/Oleglog/OlConnect/tree/main/gradle "gradle")|  |    
[native/mobilecore](/Oleglog/OlConnect/tree/main/native/mobilecore "This path skips through empty directories")| [native/mobilecore](/Oleglog/OlConnect/tree/main/native/mobilecore "This path skips through empty directories")|  |    
[scripts](/Oleglog/OlConnect/tree/main/scripts "scripts")| [scripts](/Oleglog/OlConnect/tree/main/scripts "scripts")|  |    
[.gitattributes](/Oleglog/OlConnect/blob/main/.gitattributes ".gitattributes")| [.gitattributes](/Oleglog/OlConnect/blob/main/.gitattributes ".gitattributes")|  |    
[.gitignore](/Oleglog/OlConnect/blob/main/.gitignore ".gitignore")| [.gitignore](/Oleglog/OlConnect/blob/main/.gitignore ".gitignore")|  |    
[AGENTS.md](/Oleglog/OlConnect/blob/main/AGENTS.md "AGENTS.md")| [AGENTS.md](/Oleglog/OlConnect/blob/main/AGENTS.md "AGENTS.md")|  |    
[CHANGELOG.md](/Oleglog/OlConnect/blob/main/CHANGELOG.md "CHANGELOG.md")| [CHANGELOG.md](/Oleglog/OlConnect/blob/main/CHANGELOG.md "CHANGELOG.md")|  |    
[LICENSE](/Oleglog/OlConnect/blob/main/LICENSE "LICENSE")| [LICENSE](/Oleglog/OlConnect/blob/main/LICENSE "LICENSE")|  |    
[README.md](/Oleglog/OlConnect/blob/main/README.md "README.md")| [README.md](/Oleglog/OlConnect/blob/main/README.md "README.md")|  |    
[RELEASE_NOTES_v1.6.0.md](/Oleglog/OlConnect/blob/main/RELEASE_NOTES_v1.6.0.md "RELEASE_NOTES_v1.6.0.md")| [RELEASE_NOTES_v1.6.0.md](/Oleglog/OlConnect/blob/main/RELEASE_NOTES_v1.6.0.md "RELEASE_NOTES_v1.6.0.md")|  |    
[RELEASE_NOTES_v1.6.1.md](/Oleglog/OlConnect/blob/main/RELEASE_NOTES_v1.6.1.md "RELEASE_NOTES_v1.6.1.md")| [RELEASE_NOTES_v1.6.1.md](/Oleglog/OlConnect/blob/main/RELEASE_NOTES_v1.6.1.md "RELEASE_NOTES_v1.6.1.md")|  |    
[RELEASE_NOTES_v1.6.2.md](/Oleglog/OlConnect/blob/main/RELEASE_NOTES_v1.6.2.md "RELEASE_NOTES_v1.6.2.md")| [RELEASE_NOTES_v1.6.2.md](/Oleglog/OlConnect/blob/main/RELEASE_NOTES_v1.6.2.md "RELEASE_NOTES_v1.6.2.md")|  |    
[RELEASE_NOTES_v1.6.4.md](/Oleglog/OlConnect/blob/main/RELEASE_NOTES_v1.6.4.md "RELEASE_NOTES_v1.6.4.md")| [RELEASE_NOTES_v1.6.4.md](/Oleglog/OlConnect/blob/main/RELEASE_NOTES_v1.6.4.md "RELEASE_NOTES_v1.6.4.md")|  |    
[RELEASE_NOTES_v1.6.5.md](/Oleglog/OlConnect/blob/main/RELEASE_NOTES_v1.6.5.md "RELEASE_NOTES_v1.6.5.md")| [RELEASE_NOTES_v1.6.5.md](/Oleglog/OlConnect/blob/main/RELEASE_NOTES_v1.6.5.md "RELEASE_NOTES_v1.6.5.md")|  |    
[RELEASE_NOTES_v1.6.6.md](/Oleglog/OlConnect/blob/main/RELEASE_NOTES_v1.6.6.md "RELEASE_NOTES_v1.6.6.md")| [RELEASE_NOTES_v1.6.6.md](/Oleglog/OlConnect/blob/main/RELEASE_NOTES_v1.6.6.md "RELEASE_NOTES_v1.6.6.md")|  |    
[THIRD_PARTY_NOTICES.md](/Oleglog/OlConnect/blob/main/THIRD_PARTY_NOTICES.md "THIRD_PARTY_NOTICES.md")| [THIRD_PARTY_NOTICES.md](/Oleglog/OlConnect/blob/main/THIRD_PARTY_NOTICES.md "THIRD_PARTY_NOTICES.md")|  |    
[build.gradle.kts](/Oleglog/OlConnect/blob/main/build.gradle.kts "build.gradle.kts")| [build.gradle.kts](/Oleglog/OlConnect/blob/main/build.gradle.kts "build.gradle.kts")|  |    
[gradle.properties](/Oleglog/OlConnect/blob/main/gradle.properties "gradle.properties")| [gradle.properties](/Oleglog/OlConnect/blob/main/gradle.properties "gradle.properties")|  |    
[gradlew](/Oleglog/OlConnect/blob/main/gradlew "gradlew")| [gradlew](/Oleglog/OlConnect/blob/main/gradlew "gradlew")|  |    
[gradlew.bat](/Oleglog/OlConnect/blob/main/gradlew.bat "gradlew.bat")| [gradlew.bat](/Oleglog/OlConnect/blob/main/gradlew.bat "gradlew.bat")|  |    
[keystore.properties.example](/Oleglog/OlConnect/blob/main/keystore.properties.example "keystore.properties.example")| [keystore.properties.example](/Oleglog/OlConnect/blob/main/keystore.properties.example "keystore.properties.example")|  |    
[licenses.json](/Oleglog/OlConnect/blob/main/licenses.json "licenses.json")| [licenses.json](/Oleglog/OlConnect/blob/main/licenses.json "licenses.json")|  |    
[settings.gradle.kts](/Oleglog/OlConnect/blob/main/settings.gradle.kts "settings.gradle.kts")| [settings.gradle.kts](/Oleglog/OlConnect/blob/main/settings.gradle.kts "settings.gradle.kts")|  |    
View all files  
  
## Repository files navigation

  *   * README
  * License



More items

# OlConnect

Современный клиент VPN и прокси-соединений для Android 8+. Маршрутизирует трафик через системный `VpnService`, обеспечивая обход блокировок и цензуры с использованием инновационных транспортов маскировки и стандартных протоколов.

* * *

## Поддерживаемые протоколы

### 1\. OpenFlux

  * Высокоскоростной L3 IP-туннель, инкапсулированный в протоколы облачных редакторов документов: 
    * **Yandex Docs** (поддерживаются как новый движок Volga, так и классический редактор);
    * **Mail.ru Docs** (редактор документов Mail.ru).
  * **Сквозное шифрование AES-256-GCM** : аутентифицированное шифрование всего IP-трафика с защитой от повторного воспроизведения (replay attack) и деривацией ключей через scrypt. Ключ задается через параметр `&k=<key>` в URI или редактируется в настройках профиля.
  * **RFC 792 ICMP Port Unreachable Fast TCP Fallback** : немедленный возврат ICMP-ошибки «порт недоступен» на заблокированные UDP-порты, что заставляет приложения (браузеры, мессенджеры) мгновенно переключаться на TCP без ожидания таймаутов.
  * Встроенный резолвер DNS-over-HTTPS (DoH: Cloudflare, Google, Quad9, Yandex) и выбор пользовательского DNS.
  * Автоматическая компрессия пакетов (LZ4 `compressedTransport` и batched streaming).
  * Работает напрямую без необходимости создания комнат видеоконференций.



### 2\. OlConnect (WebRTC)

  * Инкапсуляция TCP/IP-трафика внутри сессий видеоконференций доверенных белых сервисов: 
    * **Яндекс.Телемост** (`vp8channel`, `videochannel`);
    * **Jitsi Meet** (`vp8channel`, `datachannel`, `seichannel`, `videochannel`);
    * **WB Stream** (`vp8channel`, `datachannel`).
  * Поддержка аппаратного и программного кодирования VP8 с контролем целостности пакетов.



### 3\. Стандартные протоколы (на базе ядра Xray)

  * **VLESS** : поддержка транспортов TCP/raw, WebSocket, gRPC, XHTTP, а также протоколов безопасности TLS, REALITY и VLESS Vision flow.
  * **VMess** и **Trojan**.
  * **Shadowsocks**.



* * *

## Импорт конфигураций и подписки

  * **Глубокие ссылки (Deep Links)** : клик по ссылкам вида `olconnect://`, `openflux://`, `vless://`, `vmess://`, `trojan://`, `ss://`.
  * **Спецификация ссылки OpenFlux** : 
```
openflux://<yandex|mailru>?url=<url_документа>[&t=<транспорт>][&k=<ключ_шифрования>][&d=<dns>]#<название>
        

```

  * **QR-коды** : сканирование камерой или импорт изображения QR из галереи.
  * **Вставка из буфера обмена** или импорт файлов конфигураций.
  * **Умные подписки с зеркалами** : 
    * Поддержка ссылок на подписки `https://.../sub/<slug>` сервера OlConnect Manager.
    * Автоматический fallback на зашифрованное зеркало в **Яндекс.Диске** (AES-256-GCM), если основной сервер недоступен или заблокирован.



* * *

## Маршрутизация

  * **Пресеты маршрутизации** : 
    * _Весь трафик через VPN_ ;
    * _Россия напрямую (Bypass Russia)_ : трафик к российским ресурсам (`geoip:ru`, `geosite:category-ru`) идет напрямую, зарубежный трафик — через защищенный туннель.
  * **Выборочная маршрутизация приложений (Per-App)** : 
    * Все приложения;
    * Все, кроме выбранных;
    * Только выбранные приложения.
  * **Пользовательские правила маршрутизации** : 
    * Точные домены, суффиксы доменов (`.domain.com`), IP-адреса, CIDR-диапазоны и пакеты приложений (`package:com.example.app`);
    * Действия для правил: «Через VPN», «Напрямую (Direct)», «Блокировать (Block)».
  * **Защита от утечки реального IP сервера (SO_BINDTODEVICE bypass protection)** : 
    * Изоляция сетевого интерфейса `tun0` от вредоносных приложений и системных сканеров (таких как `RKNHardering`, `curl --interface tun0`);
    * Пакетная валидация владельца соединения (UID) через `ConnectivityManager.getConnectionOwnerUid` на Android 10+ с кешированием состояний и мгновенным сбросом неразрешенных сессий (TCP RST / ICMP Port Unreachable).



* * *

## Встроенное обновление приложения

Приложение умеет автоматически проверять обновления и безопасно скачивать APK-файлы релизов с GitHub прямо через активный туннель или напрямую, с проверкой контрольной суммы SHA-256 и сертификата подписи.

* * *

## Сборка

Сборка нативных компонентов и приложения осуществляется через GitHub Actions. Локальные требования для сборки:

  * JDK 17
  * Android SDK 36 (NDK 28.2)
  * Go (согласно `native/mobilecore/go.mod`)



* * *

## Лицензия

Proprietary / Open Source dependencies (см. `THIRD_PARTY_NOTICES.md`).

## About

No description, website, or topics provided.

### Resources

Readme

License

[Activity](/Oleglog/OlConnect/activity)

### Stars

**21** stars

### Watchers

**2** watching

### Forks

[**3** forks](/Oleglog/OlConnect/forks)

[Report repository](/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2FOleglog%2FOlConnect&report=Oleglog+%28user%29)

## Releases

## Packages

## Contributors

## Languages

## Footer

[ ](https://github.com) (C) 2026 GitHub, Inc. 

### Footer navigation

  * [Terms](https://docs.github.com/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/site-policy/privacy-policies/github-privacy-statement)
  * [Security](https://github.com/security)
  * [Status](https://www.githubstatus.com/)
  * [Community](https://github.community/)
  * [Docs](https://docs.github.com/)
  * [Contact](https://support.github.com?tags=dotcom-footer)
  * Manage cookies 
  * Do not share my personal information 



You can’t perform that action at this time.